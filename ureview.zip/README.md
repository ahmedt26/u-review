# UReview
### Created Friday, October 1st, 2021
### Abdullah Nafees and Tahseen Ahmed

UReview is a duo project for CS 4WW3, a website used to review things.

### A1 Notes
We have excess images in some spots and the ratios aren't the same as the original,
which causes Lighthouse to flag them as issues.
They'll be fixed once we continue developing the site (proper backend/dynamic system.)

### Resources Used
Bootstrap 5
https://getbootstrap.com/docs/5.1/getting-started/introduction/

We used  the Navbar and Card examples as of now.