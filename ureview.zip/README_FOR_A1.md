# UReview - README for Assignment One
### Created Friday, October 1st, 2021
### Abdullah Nafees and Tahseen Ahmed

UReview is a duo project for CS 4WW3, a website used to review things.
This is a local README.md for A1, and not to be shared with TAs/instructor only
as it contains info about us (students). The regular README will also be
added to the zip file.

### Partner Details:
Tahseen Ahmed - ahmedt26
Abdullah Nafees - nafeesa

### A1 Notes
We have excess images in some spots and the ratios aren't the same as the original,
which causes Lighthouse to flag them as issues.
They'll be fixed once we continue developing the site (proper backend/dynamic system.)

### Resources Used
Bootstrap 5
https://getbootstrap.com/docs/5.1/getting-started/introduction/

We used  the Navbar and Card examples as of now.

### LINK TO SERVERS
This is the link to Tahseen's Server (ahmedt26)
http://3.143.77.165/

This is the link to Abdullah's Server (nafeesa)

http://3.129.30.166/ureview/
